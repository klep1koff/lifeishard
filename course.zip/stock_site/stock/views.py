from django.http import JsonResponse
from django.shortcuts import render

from .models import *


# Create your views here.
def index(request):
    return render(request, "stock/index.html")


def inventory(request):
    materials = Material.objects.all()
    return render(request, "stock/inventory.html", {"materials": materials})


def suppliers(request):
    suppliers = Supplier.objects.all()
    return render(request, "stock/suppliers.html", {"suppliers": suppliers})


def recipients(request):
    recipients = Recipient.objects.all()
    return render(request, "stock/recipients.html", {"recipients": recipients})


def staff(request):
    staff = Staff.objects.all()
    return render(request, "stock/staff.html", {"staff_list": staff})


def orders(request):
    if request.method == "POST":
        staff_id = request.POST.get("staff")
        material_id = request.POST.get("material")
        recipient_id = request.POST.get("recipient")
        quantity = request.POST.get("quantity")
        try:
            material = Material.objects.filter(id=material_id).first()
            staff = Staff.objects.filter(id=staff_id).first()
            recipient = Recipient.objects.filter(id=recipient_id).first()
        except Material.DoesNotExist:
            return JsonResponse({"error": "Invalid material ID"})
        except Staff.DoesNotExist:
            return JsonResponse({"error": "Invalid staff ID"})
        except Recipient.DoesNotExist:
            return JsonResponse({"error": "Invalid recipient ID"})

        new_order = Order.objects.create(
            staff=staff,
            material=material,
            recipient=recipient,
            quantity=int(quantity),
        )

        data = {
            "id": new_order.id,
            "quantity": new_order.quantity,
            "material": new_order.material.name,
            "recipient": new_order.recipient.name,
            "staff": new_order.staff.name,
        }
        return JsonResponse(data)

    orders = Order.objects.all()
    recipients = Recipient.objects.all()
    staff = Staff.objects.all()
    materials = Material.objects.all()
    return render(
        request,
        "stock/orders.html",
        {"orders": orders, "recipients": recipients, "staff": staff, "materials": materials},
    )
