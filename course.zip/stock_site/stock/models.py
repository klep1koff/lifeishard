from django.core.exceptions import ValidationError
from django.db import models

# Create your models here.


class Material(models.Model):
    id = models.AutoField(primary_key=True)
    name = models.CharField(max_length=100)
    quantity = models.PositiveIntegerField(default=0)
    supplier = models.ManyToManyField("Supplier", related_name="materials_supplied")
    recipients = models.ManyToManyField("Recipient", through="Order", related_name="materials_ordered")
    image = models.ImageField(upload_to="images/materials/", blank=True, null=True)
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)

    def __str__(self):
        return self.name


class Supplier(models.Model):
    name = models.CharField(max_length=100)
    image = models.ImageField(upload_to="images/suppliers/", blank=True, null=True)

    def __str__(self):
        return self.name


class Order(models.Model):
    id = models.AutoField(primary_key=True)
    status = models.BooleanField(default=False)
    staff = models.ForeignKey("Staff", on_delete=models.SET_NULL, null=True)
    material = models.ForeignKey(Material, on_delete=models.CASCADE)
    recipient = models.ForeignKey("Recipient", on_delete=models.CASCADE)
    quantity = models.PositiveIntegerField(default=0)
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)

    def clean(self):
        if self.quantity > self.material.quantity:
            raise ValidationError(
                f"Количество материала в заказе не может быть больше, чем максимальное количество самого материала ({self.material.quantity})."
            )


class Recipient(models.Model):
    name = models.CharField(max_length=100)
    image = models.ImageField(upload_to="images/recipients/", blank=True, null=True)

    def __str__(self):
        return self.name


class Staff(models.Model):
    name = models.CharField(max_length=100)
    image = models.ImageField(upload_to="images/staff/", blank=True, null=True)

    def __str__(self):
        return self.name
