# create a urls file for django apps
from django.urls import path

from . import views

urlpatterns = [
    path("", views.index, name="index"),
    path("inventory/", views.inventory, name="inventory"),
    path("suppliers/", views.suppliers, name="suppliers"),
    path("recipients/", views.recipients, name="recipients"),
    path("staff/", views.staff, name="staff"),
    path("orders/", views.orders, name="orders"),
]
