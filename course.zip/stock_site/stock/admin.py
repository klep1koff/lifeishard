from django.contrib import admin

from .models import *

# Register your models here.
admin.site.register(Material)
admin.site.register(Supplier)
admin.site.register(Recipient)
admin.site.register(Staff)
admin.site.register(Order)